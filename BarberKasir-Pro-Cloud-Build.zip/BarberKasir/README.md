# BarberKasir Pro

Aplikasi kasir barbershop Android, offline dan 1 HP.

## Fitur
- Kasir layanan Haircut/Fade/Mullet dan layanan lain
- Barber dan komisi
- Pelanggan
- Produk dan stok
- Pembayaran Cash/Transfer/QRIS
- Diskon dan kembalian
- Riwayat transaksi
- Struk yang bisa dibagikan
- Laporan omzet dan komisi
- Profil barbershop
- PIN admin
- Backup/restore JSON
- Offline, data tersimpan lokal di HP

PIN awal: `1234`

## Build APK dari HP (Cloud Build)

Project sudah memiliki GitHub Actions di `.github/workflows/build-apk.yml`.

1. Upload seluruh isi project ke repository GitHub.
2. Buka **Actions**.
3. Pilih **Build BarberKasir Pro APK**.
4. Tekan **Run workflow**.
5. Setelah selesai, download artifact **BarberKasir-Pro-debug-apk**.
6. Extract dan install `app-debug.apk` di Android.

Panduan lengkap: lihat `README-CLOUD-BUILD.md`.

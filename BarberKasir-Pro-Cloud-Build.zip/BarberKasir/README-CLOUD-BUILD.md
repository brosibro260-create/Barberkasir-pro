# BarberKasir Pro — Cloud Build

Project ini disiapkan untuk dibuild menjadi APK menggunakan GitHub Actions, sehingga tidak membutuhkan Android Studio di HP.

## Cara build dari HP Android

1. Buat/login akun GitHub.
2. Buat repository baru, misalnya `barberkasir-pro`.
3. Upload seluruh isi folder project ini ke repository. Pastikan `.github/workflows/build-apk.yml` ikut terupload.
4. Buka tab **Actions** di repository.
5. Pilih workflow **Build BarberKasir Pro APK**.
6. Tekan **Run workflow** jika ingin menjalankan manual.
7. Setelah selesai, buka hasil workflow dan bagian **Artifacts**.
8. Download `BarberKasir-Pro-debug-apk.zip` ke HP.
9. Extract ZIP tersebut dan install `app-debug.apk`.

## Catatan

- Workflow memakai JDK 17 dan Gradle 8.9.
- APK yang dihasilkan adalah debug APK untuk pengujian/pemakaian pribadi.
- Untuk distribusi Play Store, diperlukan konfigurasi signing/release terpisah.

package com.barberkasir.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

private data class Service(val id:String,val name:String,val price:Int,val commission:Int)
private data class Barber(val id:String,val name:String,val commission:Int)
private data class Customer(val id:String,val name:String,val phone:String,val notes:String)
private data class Product(val id:String,val name:String,val price:Int,val stock:Int,val cost:Int)
private data class Sale(val id:String,val date:Long,val customer:String,val barber:String,val items:String,val total:Int,val payment:String,val paid:Int,val change:Int,val discount:Int)

private class Store(ctx:Context) {
    private val p=ctx.getSharedPreferences("barber_pro",Context.MODE_PRIVATE)
    var shopName by mutableStateOf(p.getString("shop","BARBER SHOP") ?: "BARBER SHOP")
    var address by mutableStateOf(p.getString("address","") ?: "")
    var phone by mutableStateOf(p.getString("phone","") ?: "")
    var pin by mutableStateOf(p.getString("pin","1234") ?: "1234")
    var services by mutableStateOf(loadServices())
    var barbers by mutableStateOf(loadBarbers())
    var customers by mutableStateOf(loadCustomers())
    var products by mutableStateOf(loadProducts())
    var sales by mutableStateOf(loadSales())
    private fun arr(k:String)=JSONArray(p.getString(k,"[]"))
    private fun loadServices()=runCatching{val a=arr("services"); List(a.length()){val o=a.getJSONObject(it);Service(o.getString("id"),o.getString("name"),o.getInt("price"),o.optInt("commission",0))}}.getOrElse{listOf(Service("s1","Haircut",30000,5000),Service("s2","Fade",40000,7000),Service("s3","Mullet",45000,8000),Service("s4","Cuci + Styling",25000,4000))}
    private fun loadBarbers()=runCatching{val a=arr("barbers");List(a.length()){val o=a.getJSONObject(it);Barber(o.getString("id"),o.getString("name"),o.optInt("commission",0))}}.getOrElse{listOf(Barber("b1","Barber 1",20),Barber("b2","Barber 2",20))}
    private fun loadCustomers()=runCatching{val a=arr("customers");List(a.length()){val o=a.getJSONObject(it);Customer(o.getString("id"),o.getString("name"),o.optString("phone"),o.optString("notes"))}}.getOrElse{emptyList()}
    private fun loadProducts()=runCatching{val a=arr("products");List(a.length()){val o=a.getJSONObject(it);Product(o.getString("id"),o.getString("name"),o.getInt("price"),o.getInt("stock"),o.optInt("cost",0))}}.getOrElse{listOf(Product("p1","Pomade",35000,10,20000),Product("p2","Hair Tonic",30000,10,15000))}
    private fun loadSales()=runCatching{val a=arr("sales");List(a.length()){val o=a.getJSONObject(it);Sale(o.getString("id"),o.getLong("date"),o.optString("customer"),o.optString("barber"),o.optString("items"),o.getInt("total"),o.optString("payment"),o.optInt("paid"),o.optInt("change"),o.optInt("discount"))}}.getOrElse{emptyList()}
    private fun save(k:String,a:JSONArray){p.edit().putString(k,a.toString()).apply()}
    fun saveAll(){shopName=shopName.trim();p.edit().putString("shop",shopName).putString("address",address).putString("phone",phone).putString("pin",pin).apply();save("services",JSONArray().also{services.forEach{x->it.put(JSONObject().apply{put("id",x.id);put("name",x.name);put("price",x.price);put("commission",x.commission)})}});save("barbers",JSONArray().also{barbers.forEach{x->it.put(JSONObject().apply{put("id",x.id);put("name",x.name);put("commission",x.commission)})}});save("customers",JSONArray().also{customers.forEach{x->it.put(JSONObject().apply{put("id",x.id);put("name",x.name);put("phone",x.phone);put("notes",x.notes)})}});save("products",JSONArray().also{products.forEach{x->it.put(JSONObject().apply{put("id",x.id);put("name",x.name);put("price",x.price);put("stock",x.stock);put("cost",x.cost)})}});save("sales",JSONArray().also{sales.forEach{x->it.put(JSONObject().apply{put("id",x.id);put("date",x.date);put("customer",x.customer);put("barber",x.barber);put("items",x.items);put("total",x.total);put("payment",x.payment);put("paid",x.paid);put("change",x.change);put("discount",x.discount)})}})}
    fun reset(){p.edit().clear().apply();services=loadServices();barbers=loadBarbers();customers=loadCustomers();products=loadProducts();sales=loadSales();shopName="BARBER SHOP";address="";phone="";pin="1234"}
    fun backup():String{saveAll();return p.getString("services","[]")!!.let{JSONObject().put("version",2).put("shop",shopName).put("address",address).put("phone",phone).put("pin",pin).put("services",JSONArray(p.getString("services","[]"))).put("barbers",JSONArray(p.getString("barbers","[]"))).put("customers",JSONArray(p.getString("customers","[]"))).put("products",JSONArray(p.getString("products","[]"))).put("sales",JSONArray(p.getString("sales","[]"))).toString(2)}}
    fun restore(json:String){val o=JSONObject(json);p.edit().putString("shop",o.optString("shop","BARBER SHOP")).putString("address",o.optString("address","")).putString("phone",o.optString("phone","")).putString("pin",o.optString("pin","1234")).putString("services",o.getJSONArray("services").toString()).putString("barbers",o.getJSONArray("barbers").toString()).putString("customers",o.getJSONArray("customers").toString()).putString("products",o.getJSONArray("products").toString()).putString("sales",o.getJSONArray("sales").toString()).apply();shopName=p.getString("shop","BARBER SHOP")!!;address=p.getString("address","")!!;phone=p.getString("phone","")!!;pin=p.getString("pin","1234")!!;services=loadServices();barbers=loadBarbers();customers=loadCustomers();products=loadProducts();sales=loadSales()}
}

private fun rupiah(n:Int)=NumberFormat.getCurrencyInstance(Locale("id","ID")).format(n).replace(",00","")
private fun date(t:Long)=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale("id")).format(Date(t))
private fun id()=System.currentTimeMillis().toString()

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{BarberApp(this)}}
}

@Composable fun BarberApp(ctx:Context){
 val store=remember{Store(ctx)}; var unlocked by remember{mutableStateOf(false)}; var pinInput by remember{mutableStateOf("")}
 if(!unlocked){PinScreen(store.shopName,pinInput,{pinInput=it},{if(it==store.pin)unlocked=true else Toast.makeText(ctx,"PIN salah",Toast.LENGTH_SHORT).show()}) ; return}
 var tab by remember{mutableIntStateOf(0)}
 MaterialTheme{Scaffold(bottomBar={NavigationBar{listOf("Kasir" to Icons.Default.PointOfSale,"Riwayat" to Icons.Default.ReceiptLong,"Pelanggan" to Icons.Default.People,"Laporan" to Icons.Default.BarChart,"Lainnya" to Icons.Default.Settings).forEachIndexed{i,x->NavigationBarItem(i==tab,{tab=i},icon={Icon(x.second,null)},label={Text(x.first)})}}}){pad->Box(Modifier.padding(pad)){when(tab){0->Cashier(ctx,store);1->History(ctx,store);2->Customers(store);3->Reports(store);4->More(ctx,store,{unlocked=false})}}}}
}

@Composable fun PinScreen(name:String,pin:String,onPin:(String)->Unit,onGo:()->Unit){Column(Modifier.fillMaxSize().padding(28.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){Text(name,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("BarberKasir Pro",color=MaterialTheme.colorScheme.primary);Spacer(Modifier.height(30.dp));OutlinedTextField(pin,{onPin(it.take(8))},label={Text("PIN Admin")},singleLine=true);Spacer(Modifier.height(12.dp));Button(onGo){Text("Masuk")};Text("PIN awal: 1234",fontSize=12.sp,color=MaterialTheme.colorScheme.outline)}}

@Composable fun Cashier(ctx:Context,s:Store){
 var barber by remember{mutableStateOf(s.barbers.firstOrNull())};var customer by remember{mutableStateOf<Customer?>(null)};var selected by remember{mutableStateOf(listOf<Service>())};var product by remember{mutableStateOf<Product?>(null)};var qty by remember{mutableIntStateOf(1)};var discount by remember{mutableIntStateOf(0)};var paid by remember{mutableStateOf("")};var payment by remember{mutableStateOf("Cash")};var show by remember{mutableStateOf(false)}
 val subtotal=selected.sumOf{it.price}+(product?.price?:0)*qty;val total=(subtotal-discount).coerceAtLeast(0);val paidN=paid.toIntOrNull()?:0
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){Text("Transaksi Baru",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));Section("Barber"){Dropdown(barber?.name?:(s.barbers.firstOrNull()?.name? :"-"),s.barbers.map{it.name}){barber=s.barbers[it]}};Section("Layanan"){s.services.forEach{v->FilterChip(selected.contains(v),{selected=if(selected.contains(v))selected-v else selected+v},label={Text("${v.name} • ${rupiah(v.price)}")},modifier=Modifier.padding(end=6.dp,bottom=6.dp))}};Section("Produk"){Dropdown(product?.name? : "Tanpa produk",listOf("Tanpa produk")+s.products.filter{it.stock>0}.map{it.name}){if(it==0)product=null else product=s.products.filter{it.stock>0}[it-1]};if(product!=null)Row(verticalAlignment=Alignment.CenterVertically){Text("Qty");IconButton({qty=(qty-1).coerceAtLeast(1)}){Icon(Icons.Default.Remove,null)};Text("$qty");IconButton({qty++}){Icon(Icons.Default.Add,null)}}};Section("Pelanggan"){Dropdown(customer?.name? : "Pelanggan umum",listOf("Pelanggan umum")+s.customers.map{it.name}){customer=if(it==0)null else s.customers[it-1]}};Section("Pembayaran"){Dropdown(payment,listOf("Cash","Transfer","QRIS")){payment=listOf("Cash","Transfer","QRIS")[it]};OutlinedTextField(discount.toString(),{discount=it.filter{c->c.isDigit()}.toIntOrNull()?:0},label={Text("Diskon (Rp)")},singleLine=true);OutlinedTextField(paid,{paid=it.filter{c->c.isDigit()}.take(9)},label={Text("Dibayar (Rp)")},singleLine=true)};Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("TOTAL",fontSize=13.sp);Text(rupiah(total),style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);if(payment=="Cash")Text("Kembalian: ${rupiah((paidN-total).coerceAtLeast(0))}")}};Button({if(total>0 && (payment!="Cash"||paidN>=total)){val now=System.currentTimeMillis();val items=(selected.map{it.name}+listOfNotNull(product?.let{"$it x$qty"})).joinToString(", ");s.sales=listOf(Sale(id(),now,customer?.name?:"Umum",barber?.name?:"-",items,total,payment,paidN,(paidN-total).coerceAtLeast(0),discount))+s.sales;product?.let{p->s.products=s.products.map{if(it.id==p.id)it.copy(stock=(it.stock-qty).coerceAtLeast(0)) else it}};s.saveAll();Toast.makeText(ctx,"Transaksi tersimpan",Toast.LENGTH_SHORT).show();selected=listOf();product=null;paid="";discount=0}},Modifier.fillMaxWidth()){Icon(Icons.Default.Check,null);Spacer(Modifier.width(8.dp));Text("SIMPAN TRANSAKSI")}}
}

@Composable fun History(ctx:Context,s:Store){var q by remember{mutableStateOf("")};var share by remember{mutableStateOf<Sale?>(null)};Column(Modifier.fillMaxSize().padding(16.dp)){Text("Riwayat Transaksi",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);OutlinedTextField(q,{q=it},label={Text("Cari transaksi / pelanggan")},modifier=Modifier.fillMaxWidth());Spacer(Modifier.height(10.dp));LazyColumn{items(s.sales.filter{it.customer.contains(q,true)||it.items.contains(q,true)}){v->Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(14.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(rupiah(v.total),fontWeight=FontWeight.Bold);Text(date(v.date),fontSize=12.sp)};Text("${v.customer} • ${v.barber}");Text(v.items,fontSize=13.sp);Text("${v.payment} • Dibayar ${rupiah(v.paid)}");TextButton({share=v}){Text("Bagikan struk")}}}}};if(share!=null)ReceiptDialog(s,share!!,{share=null})}}

@Composable fun ReceiptDialog(s:Store,v:Sale,onClose:()->Unit){AlertDialog(onDismissRequest=onClose,title={Text("Struk Transaksi")},text={Text("${s.shopName}\n${s.address}\n${s.phone}\n----------------\n${date(v.date)}\nPelanggan: ${v.customer}\nBarber: ${v.barber}\n${v.items}\n----------------\nTOTAL: ${rupiah(v.total)}\nBayar: ${rupiah(v.paid)}\nKembali: ${rupiah(v.change)}\n${v.payment}\n\nTerima kasih!")},confirmButton={TextButton(onClose){Text("Tutup")}})}

@Composable fun Customers(s:Store){var add by remember{mutableStateOf(false)};var name by remember{mutableStateOf("")};var phone by remember{mutableStateOf("")};Column(Modifier.fillMaxSize().padding(16.dp)){Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Pelanggan",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);FloatingActionButton({add=true}){Icon(Icons.Default.Add,null)}};Spacer(Modifier.height(10.dp));LazyColumn{items(s.customers){c->Card(Modifier.fillMaxWidth().padding(vertical=4.dp)){ListItem(headlineContent={Text(c.name)},supportingContent={Text("${c.phone} • ${s.sales.count{it.customer==c.name}} kunjungan")})}}};if(add)DialogForm("Tambah Pelanggan",listOf("Nama","No. HP","Catatan")){vals->s.customers=s.customers+Customer(id(),vals[0],vals[1],vals[2]);s.saveAll();add=false}{add=false}}}

@Composable fun Reports(s:Store){val today=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0)}.timeInMillis;val ts=s.sales.filter{it.date>=today};val omzet=ts.sumOf{it.total};val komisi=ts.sumOf{sale->val b=s.barbers.find{it.name==sale.barber};if(b!=null)(sale.total*b.commission/100)else 0};Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)){Text("Laporan Hari Ini",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Metric("Omzet",rupiah(omzet));Metric("Transaksi","${ts.size}");Metric("Komisi Barber",rupiah(komisi));Text("Stok Produk",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=20.dp));s.products.forEach{ListItem(headlineContent={Text(it.name)},trailingContent={Text("${it.stock} pcs")},supportingContent={Text(rupiah(it.price))})};Text("Ringkasan 30 hari",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=20.dp));val month=System.currentTimeMillis()-30L*24*60*60*1000;Text("Omzet: ${rupiah(s.sales.filter{it.date>=month}.sumOf{it.total})}");Text("Transaksi: ${s.sales.count{it.date>=month}}")}}
@Composable fun Metric(a:String,b:String){Card(Modifier.fillMaxWidth().padding(vertical=5.dp)){Column(Modifier.padding(16.dp)){Text(a,fontSize=13.sp);Text(b,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold)}}}

@Composable fun More(ctx:Context,s:Store,logout:()->Unit){var screen by remember{mutableStateOf(0)};var msg by remember{mutableStateOf("")};val export=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->if(uri!=null)ctx.contentResolver.openOutputStream(uri)?.use{it.write(s.backup().toByteArray())}};val import=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)runCatching{ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText()}.onSuccess{s.restore(it);msg="Data berhasil dipulihkan"}.onFailure{msg="File backup tidak valid"}}
 Column(Modifier.fillMaxSize().padding(16.dp)){Text("Pengaturan",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);SettingButton("Profil Barbershop",Icons.Default.Store){screen=1};SettingButton("Kelola Layanan",Icons.Default.ContentCut){screen=2};SettingButton("Kelola Barber",Icons.Default.Person){screen=3};SettingButton("Kelola Produk & Stok",Icons.Default.Inventory2){screen=4};SettingButton("Backup Data",Icons.Default.UploadFile){export.launch("backup-barberkasir.json")};SettingButton("Restore Data",Icons.Default.Download){import.launch(arrayOf("application/json","text/plain"))};SettingButton("Ganti PIN",Icons.Default.Lock){screen=5};SettingButton("Keluar ke PIN",Icons.Default.Logout,logout);if(msg.isNotEmpty())Text(msg,color=MaterialTheme.colorScheme.primary);if(screen>0)ManageDialog(ctx,s,screen){screen=0}}}
@Composable fun SettingButton(t:String,icon:androidx.compose.ui.graphics.vector.ImageVector,click:()->Unit){OutlinedButton(click,Modifier.fillMaxWidth().padding(vertical=4.dp)){Icon(icon,null);Spacer(Modifier.width(10.dp));Text(t)}}

@Composable fun ManageDialog(ctx:Context,s:Store,screen:Int,close:()->Unit){val title=when(screen){1->"Profil Barbershop";2->"Tambah Layanan";3->"Tambah Barber";4->"Tambah Produk";else->"Ganti PIN"};var vals by remember{mutableStateOf(List(if(screen==1)3 else if(screen==4)3 else 2){""})};AlertDialog(onDismissRequest=close,title={Text(title)},text={Column{if(screen==1){OutlinedTextField(s.shopName,{s.shopName=it},label={Text("Nama")});OutlinedTextField(s.address,{s.address=it},label={Text("Alamat")});OutlinedTextField(s.phone,{s.phone=it},label={Text("Telepon")})}else{val labels=when(screen){2->listOf("Nama layanan","Harga");3->listOf("Nama barber","Komisi %");4->listOf("Nama produk","Harga jual","Stok") ;else->listOf("PIN baru","Ulangi PIN")};labels.forEachIndexed{i,l->OutlinedTextField(vals[i],{x->vals=vals.toMutableList().also{it[i]=x}},label={Text(l)},modifier=Modifier.fillMaxWidth())}}},confirmButton={Button({when(screen){1->s.saveAll();2->if(vals[0].isNotBlank()){s.services=s.services+Service(id(),vals[0],vals[1].toIntOrNull()?:0,0);s.saveAll()};3->if(vals[0].isNotBlank()){s.barbers=s.barbers+Barber(id(),vals[0],vals[1].toIntOrNull()?:0);s.saveAll()};4->if(vals[0].isNotBlank()){s.products=s.products+Product(id(),vals[0],vals[1].toIntOrNull()?:0,vals[2].toIntOrNull()?:0,0);s.saveAll()};5->if(vals[0]==vals[1]&&vals[0].length>=4){s.pin=vals[0];s.saveAll()}};close()}){Text("Simpan")}},dismissButton={TextButton(close){Text("Batal")}})}

@Composable fun Section(t:String,content:@Composable ColumnScope.()->Unit){Text(t,style=MaterialTheme.typography.titleMedium,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=12.dp,bottom=6.dp));Column(content)}
@Composable fun Dropdown(value:String,items:List<String>,onSelect:(Int)->Unit){var open by remember{mutableStateOf(false)};Box{OutlinedButton({open=true},Modifier.fillMaxWidth()){Text(value);Spacer(Modifier.weight(1f));Icon(Icons.Default.ArrowDropDown,null)};DropdownMenu(open,{open=false}){items.forEachIndexed{i,x->DropdownMenuItem({Text(x)},{open=false;onSelect(i)})}}}}
@Composable fun DialogForm(title:String,labels:List<String>,onSave:(List<String>)->Unit,onCancel:()->Unit){var v by remember{mutableStateOf(List(labels.size){""})};AlertDialog(onDismissRequest=onCancel,title={Text(title)},text={Column{labels.forEachIndexed{i,l->OutlinedTextField(v[i],{x->v=v.toMutableList().also{it[i]=x}},label={Text(l)})}}},confirmButton={Button({onSave(v)}){Text("Simpan")}},dismissButton={TextButton(onCancel){Text("Batal")}})}
